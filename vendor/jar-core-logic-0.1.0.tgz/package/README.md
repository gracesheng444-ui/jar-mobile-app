# jar-core-logic

Stack-agnostic core business logic for the Shared Memory Jar app. Pure
functions, no I/O, no framework dependency — designed to be dropped into a
Node backend and/or reused in a React Native client.

## Layout

- `src/types.ts` — shared domain types (Jar, CycleRecord, StreakState, UserProfile)
- `src/cycle.ts` — rolling 24h UTC cycle boundaries, open/close transitions
- `src/repair.ts` — manual streak-repair application during the grace window
- `src/streak.ts` — streak increment/reset/freeze transitions
- `src/repairQuota.ts` — per-user monthly repair-pass refill (IANA timezone aware, idempotent)
- `src/starSizing.ts` — Mode A (countdown, fixed) and Mode B (count-up, asymptotic shrink) sizing math
- `src/avatar.ts` — manual avatar construction (trait catalog, build/set/cycle/randomize) and the validation contract a photo-to-AI avatar pipeline's output must satisfy

## Design decisions encoded here

- **Cycles**: pure rolling UTC, exactly 24h from jar creation. No DST or per-user timezone involved.
- **Streak repair**: freeze model — a repaired cycle restores the pre-miss streak value, it never increments. Only the user(s) who actually missed need to spend a pass; a partial miss resolves with one repair, a full miss needs both.
- **Repair quota refill**: keyed to each user's own current IANA timezone, latched via `lastRefilledYYYYMM` so it's idempotent regardless of how often it's checked, and re-evaluated lazily at both app-launch and spend-time (not launch only) to avoid stale-timezone bugs.
- **Star sizing**: countdown capacity/size are fixed once and never recalculated. Count-up capacity is a soft fill-ratio denominator (not a hard slot count), so overflow degrades gracefully via the shrink curve instead of hitting an undefined state.
- **Avatars**: two creation paths — manual construction (pure, lives here) and a photo-to-AI pipeline (needs network/image I/O, so it lives in the app layer). This package defines the shared trait catalog and `validateAvatarConfig`, the contract the AI pipeline's output must pass before it's trusted.

## Usage

```bash
npm install
npm test    # runs the full suite (45 tests)
npm run build
```

## Not included here

This package deliberately stops at pure logic — it doesn't include the
persistence layer, the push-notification scheduling job, the photo-to-AI
avatar generation call, or any UI/rendering code. Those are separate concerns
to wire up around this.
