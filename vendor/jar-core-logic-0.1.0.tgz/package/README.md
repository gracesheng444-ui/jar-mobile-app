# jar-core-logic

Stack-agnostic core business logic for the Shared Memory Jar app. Pure
functions, no I/O, no framework dependency — designed to be dropped into a
Node backend and/or reused in a React Native client.

## Layout

- `src/types.ts` — shared domain types (Jar, CycleRecord, StreakState, UserProfile)
- `src/cycle.ts` — rolling 24h UTC cycle boundaries, open/close transitions
- `src/repair.ts` — manual streak-repair application during the grace window
- `src/streak.ts` — streak increment/reset/freeze transitions
- `src/repairQuota.ts` — per-user monthly repair-pass refill (IANA timezone aware, idempotent)
- `src/starSizing.ts` — Mode A (countdown, fixed) and Mode B (count-up, asymptotic shrink) sizing math
- `src/avatar.ts` — manual avatar construction (trait catalog, build/set/cycle/randomize) and the validation contract a photo-to-AI avatar pipeline's output must satisfy
- `src/notifications.ts` — timing for the three notification types in jar_des.md §6 (partner activity, cycle reset, incomplete-tap reminders); decides *when*, not how to send

## Design decisions encoded here

- **Cycles**: pure rolling UTC, exactly 24h from jar creation. No DST or per-user timezone involved. One deliberate exception: `openCycleAt` lets a caller anchor a cycle's start explicitly instead of deriving it from the creation-time grid — used when a cycle opens as the result of a repair, since the grace window is exactly one cycle long, so the grid's next slot spans exactly that grace window and a late repair could otherwise hand back a next cycle with almost no time left to tap.
- **Repair vs. tap-to-move-on**: an unresolved grace window has two mutually exclusive resolutions, decided by whichever the app layer applies first — `applyRepair` (restores the pre-miss streak) or `abandonGrace` (forfeits the repair and forces the miss to resolve as expired right now, the same end state `expireGraceIfNeeded` would eventually reach on its own once the timer runs out). The app layer uses `abandonGrace` to let a plain tap during grace skip repairing and start a fresh streak immediately, instead of only ever waiting out the clock.
- **Streak repair**: freeze model — a repaired cycle restores the pre-miss streak value, it never increments. Either user in the jar can spend the single repair pass that resolves a cycle, regardless of which of them (one or both) actually missed the tap — a full miss doesn't need two independent repairs. The authoritative streak is derived by `recomputeStreak` folding cycles in strict `cycleIndex` order from wherever `lastUpdatedCycleIndex` left off, so a later cycle's completion is never counted (or discarded) by an earlier cycle's repair resolving out of order — folding just halts at the first unresolved cycle and resumes once it's repaired or its grace period expires.
- **Repair quota refill**: keyed to each user's own current IANA timezone, latched via `lastRefilledYYYYMM` so it's idempotent regardless of how often it's checked, and re-evaluated lazily at both app-launch and spend-time (not launch only) to avoid stale-timezone bugs.
- **Star sizing**: countdown capacity/size are fixed once and never recalculated. Count-up capacity is a soft fill-ratio denominator (not a hard slot count), so overflow degrades gracefully via the shrink curve instead of hitting an undefined state.
- **Avatars**: two creation paths — manual construction (pure, lives here) and a photo-to-AI pipeline (needs network/image I/O, so it lives in the app layer). This package defines the shared trait catalog and `validateAvatarConfig`, the contract the AI pipeline's output must pass before it's trusted.
- **Notifications**: only "partner activity" needs a server round-trip (it depends on the *other* device's action) — the other two (cycle reset, incomplete-tap reminders) are fully computable in advance from a `CycleRecord` alone, so the app layer can schedule them as on-device local notifications with no backend push involved. `getUpcomingTapReminders` is safe to call repeatedly (app resume, a periodic tick) since it only ever returns checkpoints still ahead of `nowUTC`.

## Usage

```bash
npm install
npm test    # runs the full suite (58 tests)
npm run build
```

## Demo

[`demo/star_drop.html`](demo/star_drop.html) — a standalone, dependency-free
page that exercises `computeCountdownCapacity()` from `src/starSizing.ts`
live: set a countdown length and drop stars into a jar one at a time,
sized and packed by the real math. Open the file directly in a browser,
no build step needed. It deliberately reuses the same jar illustration,
star shape, and pile-placement algorithm as `jar-mobile-app`, so it reads
as this package's actual output rather than a generic mockup.

[`demo/avatar_draft.html`](demo/avatar_draft.html) — cycles through the
manual avatar trait catalog from `src/avatar.ts`, wired to the real
`cycleAvatarTrait()` / `randomizeAvatar()` / `buildAvatarFromSelections()`
functions. No visual for this trait system exists elsewhere in the app yet,
so the rendering here is a new (but on-brand) design, not a port of an
existing component — see the comment above `renderAvatar()` in the file.

[`demo/avatar_chibi.html`](demo/avatar_chibi.html) — the same trait catalog
and picker wiring as `avatar_draft.html`, redrawn in a second, deliberately
different style: big chibi eyes, soft cheek blush, and chunkier rounded hair.
Kept as its own file so the two styles stay comparable side by side rather
than one replacing the other.

## Not included here

This package deliberately stops at pure logic — it doesn't include the
persistence layer, actually sending/scheduling a notification (only *when*
one is due, via `src/notifications.ts`), the photo-to-AI avatar generation
call, or any UI/rendering code. Those are separate concerns to wire up
around this. `demo/` is the one exception: a self-contained, throwaway
visualization for showing the math working, not a dependency of the
package itself.
