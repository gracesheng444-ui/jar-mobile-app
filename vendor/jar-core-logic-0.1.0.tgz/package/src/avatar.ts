export const AVATAR_OPTIONS = {
  skinTone: ['light', 'medium-light', 'medium', 'medium-dark', 'dark'] as const,
  faceShape: ['round', 'oval', 'square', 'heart'] as const,
  hairStyle: ['bald', 'short', 'long', 'wavy', 'curly', 'bun', 'spiky'] as const,
  hairColor: ['black', 'brown', 'blonde', 'red', 'gray', 'blue', 'pink'] as const,
  eyeStyle: ['default', 'happy', 'wink', 'sleepy', 'glasses'] as const,
  eyeColor: ['brown', 'blue', 'green', 'hazel', 'gray', 'amber', 'black'] as const,
  eyebrowStyle: ['default', 'raised', 'furrowed', 'thin'] as const,
  mouthStyle: ['smile', 'neutral', 'open', 'smirk'] as const,
  accessory: ['none', 'earrings', 'hat', 'headband', 'freckles'] as const,
  // A single shirt shape; this trait only picks its color now.
  clothing: ['teal', 'purple', 'cream', 'pink', 'blue', 'green'] as const,
  background: [
    'solid-blue',
    'solid-pink',
    'solid-green',
    'solid-yellow',
    'gradient-sunset',
    'gradient-ocean',
  ] as const,
};

export type AvatarSkinTone = (typeof AVATAR_OPTIONS.skinTone)[number];
export type AvatarFaceShape = (typeof AVATAR_OPTIONS.faceShape)[number];
export type AvatarHairStyle = (typeof AVATAR_OPTIONS.hairStyle)[number];
export type AvatarHairColor = (typeof AVATAR_OPTIONS.hairColor)[number];
export type AvatarEyeStyle = (typeof AVATAR_OPTIONS.eyeStyle)[number];
export type AvatarEyeColor = (typeof AVATAR_OPTIONS.eyeColor)[number];
export type AvatarEyebrowStyle = (typeof AVATAR_OPTIONS.eyebrowStyle)[number];
export type AvatarMouthStyle = (typeof AVATAR_OPTIONS.mouthStyle)[number];
export type AvatarAccessory = (typeof AVATAR_OPTIONS.accessory)[number];
export type AvatarClothing = (typeof AVATAR_OPTIONS.clothing)[number];
export type AvatarBackground = (typeof AVATAR_OPTIONS.background)[number];

export interface AvatarConfig {
  skinTone: AvatarSkinTone;
  faceShape: AvatarFaceShape;
  hairStyle: AvatarHairStyle;
  hairColor: AvatarHairColor;
  eyeStyle: AvatarEyeStyle;
  eyeColor: AvatarEyeColor;
  eyebrowStyle: AvatarEyebrowStyle;
  mouthStyle: AvatarMouthStyle;
  accessory: AvatarAccessory;
  clothing: AvatarClothing;
  background: AvatarBackground;
}

export const DEFAULT_AVATAR_CONFIG: AvatarConfig = {
  skinTone: AVATAR_OPTIONS.skinTone[0],
  faceShape: AVATAR_OPTIONS.faceShape[0],
  hairStyle: AVATAR_OPTIONS.hairStyle[0],
  hairColor: AVATAR_OPTIONS.hairColor[0],
  eyeStyle: AVATAR_OPTIONS.eyeStyle[0],
  eyeColor: AVATAR_OPTIONS.eyeColor[0],
  eyebrowStyle: AVATAR_OPTIONS.eyebrowStyle[0],
  mouthStyle: AVATAR_OPTIONS.mouthStyle[0],
  accessory: AVATAR_OPTIONS.accessory[0],
  clothing: AVATAR_OPTIONS.clothing[0],
  background: AVATAR_OPTIONS.background[0],
};

/**
 * How an AvatarConfig was produced. 'photo_ai' configs are generated outside
 * this package (the pipeline needs network/image I/O, which this package
 * deliberately avoids) — validateAvatarConfig is the contract that output
 * must pass before it's trusted here.
 */
export type AvatarSource = 'manual' | 'photo_ai';

export interface AvatarRecord {
  userId: string;
  config: AvatarConfig;
  source: AvatarSource;
  /** Opaque reference to the source photo when source is 'photo_ai'; resolved by the app/AI layer, not this package. */
  sourcePhotoId?: string;
  updatedAtUTC: Date;
}

function isValidTraitValue<K extends keyof AvatarConfig>(trait: K, value: unknown): value is AvatarConfig[K] {
  return (AVATAR_OPTIONS[trait] as readonly unknown[]).includes(value);
}

/** Manual construction: start from defaults, override with any provided selections. */
export function buildAvatarFromSelections(selections: Partial<AvatarConfig>): AvatarConfig {
  const config: AvatarConfig = { ...DEFAULT_AVATAR_CONFIG };
  for (const trait of Object.keys(selections) as (keyof AvatarConfig)[]) {
    const value = selections[trait];
    if (value === undefined) continue;
    if (!isValidTraitValue(trait, value)) {
      throw new Error(`Invalid value "${String(value)}" for avatar trait "${trait}"`);
    }
    (config[trait] as AvatarConfig[typeof trait]) = value;
  }
  return config;
}

/** Manual construction: change a single trait on an existing avatar. */
export function setAvatarTrait<K extends keyof AvatarConfig>(
  config: AvatarConfig,
  trait: K,
  value: AvatarConfig[K]
): AvatarConfig {
  if (!isValidTraitValue(trait, value)) {
    throw new Error(`Invalid value "${String(value)}" for avatar trait "${trait}"`);
  }
  return { ...config, [trait]: value };
}

/** Steps a trait to its next/previous option, wrapping around — for a "<  >" trait picker control. */
export function cycleAvatarTrait<K extends keyof AvatarConfig>(
  config: AvatarConfig,
  trait: K,
  direction: 1 | -1 = 1
): AvatarConfig {
  const options = AVATAR_OPTIONS[trait] as unknown as readonly AvatarConfig[K][];
  const currentIndex = options.indexOf(config[trait]);
  const nextIndex = (currentIndex + direction + options.length) % options.length;
  return { ...config, [trait]: options[nextIndex] };
}

/**
 * Deterministic random avatar — the caller supplies the randomness source
 * (Math.random, or a seeded generator) so this stays a pure function: same
 * randomFn output sequence in, same avatar out.
 */
export function randomizeAvatar(randomFn: () => number = Math.random): AvatarConfig {
  function pick<T>(options: readonly T[]): T {
    return options[Math.floor(randomFn() * options.length)];
  }
  return {
    skinTone: pick(AVATAR_OPTIONS.skinTone),
    faceShape: pick(AVATAR_OPTIONS.faceShape),
    hairStyle: pick(AVATAR_OPTIONS.hairStyle),
    hairColor: pick(AVATAR_OPTIONS.hairColor),
    eyeStyle: pick(AVATAR_OPTIONS.eyeStyle),
    eyeColor: pick(AVATAR_OPTIONS.eyeColor),
    eyebrowStyle: pick(AVATAR_OPTIONS.eyebrowStyle),
    mouthStyle: pick(AVATAR_OPTIONS.mouthStyle),
    accessory: pick(AVATAR_OPTIONS.accessory),
    clothing: pick(AVATAR_OPTIONS.clothing),
    background: pick(AVATAR_OPTIONS.background),
  };
}

/**
 * Validates an untyped object against the trait catalog. This is the
 * contract the photo-to-AI pipeline's output must satisfy — that pipeline
 * runs outside this package, so whatever it hands back needs to be checked
 * here before it's trusted as a real AvatarConfig.
 */
export function validateAvatarConfig(candidate: Partial<Record<keyof AvatarConfig, unknown>>): AvatarConfig {
  const config = {} as AvatarConfig;
  for (const trait of Object.keys(AVATAR_OPTIONS) as (keyof AvatarConfig)[]) {
    const value = candidate[trait];
    if (!isValidTraitValue(trait, value)) {
      throw new Error(`Invalid or missing value for avatar trait "${trait}": ${JSON.stringify(value)}`);
    }
    (config[trait] as AvatarConfig[typeof trait]) = value;
  }
  return config;
}

export function createAvatarRecord(
  userId: string,
  config: AvatarConfig,
  source: AvatarSource,
  nowUTC: Date,
  sourcePhotoId?: string
): AvatarRecord {
  if (source === 'photo_ai' && !sourcePhotoId) {
    throw new Error('sourcePhotoId is required when source is "photo_ai"');
  }
  return { userId, config, source, sourcePhotoId, updatedAtUTC: nowUTC };
}
