import { CycleRecord } from './types';

export const CYCLE_LENGTH_MS = 24 * 60 * 60 * 1000;
export const GRACE_PERIOD_MS = 24 * 60 * 60 * 1000;

/**
 * Pure rolling-UTC cycle index for a given instant. Cycles are exactly 24h
 * from jar creation, unaffected by DST or either user's local timezone
 * (Option A — locked in over the fixed-local-time alternative).
 */
export function getCycleIndexForTimestamp(jarCreatedAtUTC: Date, atUTC: Date): number {
  const elapsedMs = atUTC.getTime() - jarCreatedAtUTC.getTime();
  if (elapsedMs < 0) {
    throw new Error('Timestamp precedes jar creation');
  }
  return Math.floor(elapsedMs / CYCLE_LENGTH_MS);
}

export function getCycleWindow(
  jarCreatedAtUTC: Date,
  cycleIndex: number
): { start: Date; end: Date } {
  if (cycleIndex < 0) {
    throw new Error('cycleIndex must be non-negative');
  }
  const start = new Date(jarCreatedAtUTC.getTime() + cycleIndex * CYCLE_LENGTH_MS);
  const end = new Date(start.getTime() + CYCLE_LENGTH_MS);
  return { start, end };
}

export function openCycle(
  jarId: string,
  jarCreatedAtUTC: Date,
  cycleIndex: number,
  streakBeforeCycle: number
): CycleRecord {
  const { start, end } = getCycleWindow(jarCreatedAtUTC, cycleIndex);
  return {
    jarId,
    cycleIndex,
    cycleStartUTC: start,
    cycleEndUTC: end,
    userATapped: false,
    userBTapped: false,
    status: 'open',
    repairedBy: [],
    streakBeforeCycle,
  };
}

/**
 * Resolves a cycle at its end boundary. Both tapped -> complete. Otherwise
 * -> incomplete_grace, opening a 24h manual-repair window. The streak reset
 * itself is handled by streak.ts, driven off this status.
 */
export function closeCycle(cycle: CycleRecord): CycleRecord {
  if (cycle.status !== 'open') {
    throw new Error(`Cannot close a cycle with status "${cycle.status}"`);
  }
  if (cycle.userATapped && cycle.userBTapped) {
    return { ...cycle, status: 'complete' };
  }
  return {
    ...cycle,
    status: 'incomplete_grace',
    graceExpiresAtUTC: new Date(cycle.cycleEndUTC.getTime() + GRACE_PERIOD_MS),
  };
}

/** Call periodically (or lazily on read) to flip expired grace windows. */
export function expireGraceIfNeeded(cycle: CycleRecord, nowUTC: Date): CycleRecord {
  if (
    cycle.status === 'incomplete_grace' &&
    cycle.graceExpiresAtUTC &&
    nowUTC > cycle.graceExpiresAtUTC
  ) {
    return { ...cycle, status: 'incomplete_expired' };
  }
  return cycle;
}
