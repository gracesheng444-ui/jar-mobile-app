import { CycleRecord } from './types';

export const CYCLE_LENGTH_MS = 24 * 60 * 60 * 1000;
export const GRACE_PERIOD_MS = 24 * 60 * 60 * 1000;

/**
 * Pure rolling-UTC cycle index for a given instant. Cycles are exactly 24h
 * from jar creation, unaffected by DST or either user's local timezone
 * (Option A — locked in over the fixed-local-time alternative).
 */
export function getCycleIndexForTimestamp(jarCreatedAtUTC: Date, atUTC: Date): number {
  const elapsedMs = atUTC.getTime() - jarCreatedAtUTC.getTime();
  if (elapsedMs < 0) {
    throw new Error('Timestamp precedes jar creation');
  }
  return Math.floor(elapsedMs / CYCLE_LENGTH_MS);
}

export function getCycleWindow(
  jarCreatedAtUTC: Date,
  cycleIndex: number
): { start: Date; end: Date } {
  if (cycleIndex < 0) {
    throw new Error('cycleIndex must be non-negative');
  }
  const start = new Date(jarCreatedAtUTC.getTime() + cycleIndex * CYCLE_LENGTH_MS);
  const end = new Date(start.getTime() + CYCLE_LENGTH_MS);
  return { start, end };
}

export function openCycle(
  jarId: string,
  jarCreatedAtUTC: Date,
  cycleIndex: number,
  streakBeforeCycle: number
): CycleRecord {
  const { start, end } = getCycleWindow(jarCreatedAtUTC, cycleIndex);
  return openCycleAt(jarId, cycleIndex, start, streakBeforeCycle);
}

/**
 * Opens a cycle with an explicit start, bypassing the creation-time grid.
 * Needed for the one case where grid alignment is actively wrong: a cycle
 * resolved via repair. The grace window is exactly one cycle long, so the
 * grid's next slot spans exactly that same grace window — repairing late
 * within it can hand back a next cycle with almost no time left, or (by the
 * time the caller's next tick runs) none at all. Anchoring to nowUTC instead
 * guarantees a repair always hands back a genuine full cycle to tap in.
 */
export function openCycleAt(
  jarId: string,
  cycleIndex: number,
  startUTC: Date,
  streakBeforeCycle: number
): CycleRecord {
  return {
    jarId,
    cycleIndex,
    cycleStartUTC: startUTC,
    cycleEndUTC: new Date(startUTC.getTime() + CYCLE_LENGTH_MS),
    userATapped: false,
    userBTapped: false,
    status: 'open',
    repairedBy: [],
    streakBeforeCycle,
  };
}

/**
 * Resolves a cycle at its end boundary. Both tapped -> complete. Otherwise
 * -> incomplete_grace, opening a 24h manual-repair window. The streak reset
 * itself is handled by streak.ts, driven off this status.
 */
export function closeCycle(cycle: CycleRecord): CycleRecord {
  if (cycle.status !== 'open') {
    throw new Error(`Cannot close a cycle with status "${cycle.status}"`);
  }
  if (cycle.userATapped && cycle.userBTapped) {
    return { ...cycle, status: 'complete' };
  }
  return {
    ...cycle,
    status: 'incomplete_grace',
    graceExpiresAtUTC: new Date(cycle.cycleEndUTC.getTime() + GRACE_PERIOD_MS),
  };
}

/** Call periodically (or lazily on read) to flip expired grace windows. */
export function expireGraceIfNeeded(cycle: CycleRecord, nowUTC: Date): CycleRecord {
  if (
    cycle.status === 'incomplete_grace' &&
    cycle.graceExpiresAtUTC &&
    nowUTC > cycle.graceExpiresAtUTC
  ) {
    return { ...cycle, status: 'incomplete_expired' };
  }
  return cycle;
}

/**
 * Abandons an unresolved grace window right now, instead of waiting for its timer — the
 * tap-first path: tapping instead of repairing forfeits the repair option for this miss and
 * forces it to resolve as expired immediately, the same end state expireGraceIfNeeded would
 * eventually produce on its own. Repair and "tap to move on" are meant to race each other;
 * whichever the caller does first is the one that applies.
 */
export function abandonGrace(cycle: CycleRecord): CycleRecord {
  if (cycle.status !== 'incomplete_grace') {
    throw new Error(`Cannot abandon a cycle with status "${cycle.status}"`);
  }
  return { ...cycle, status: 'incomplete_expired' };
}
