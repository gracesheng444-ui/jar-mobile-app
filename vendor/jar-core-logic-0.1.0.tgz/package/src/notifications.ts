import { CycleRecord } from './types';

/**
 * The three notification types from jar_des.md section 6:
 *
 * - Partner Activity: fires immediately when a user taps, addressed to
 *   their partner, regardless of the partner's own tap status. This is
 *   event-driven (triggered the moment a tap happens), not time-based, so
 *   there is no schedule to compute and no function for it here — the app
 *   layer sends it directly off a successful tap.
 * - Cycle Reset: fires once, at the moment a cycle closes and the next one
 *   opens. See getCycleResetFireTime.
 * - Incomplete Tap Reminders: fire at fixed remaining-time checkpoints
 *   before a cycle closes, only for a user who hasn't tapped yet. See
 *   getUpcomingTapReminders.
 *
 * This module only decides *when* a notification is due — sending it (a
 * push call, a local OS-scheduled notification, etc.) is I/O and lives in
 * the app layer, same split as the rest of this package.
 */
export type ReminderInterval = '12h' | '3h' | '1h' | '30m' | '5m';

export interface ScheduledReminder {
  interval: ReminderInterval;
  fireAtUTC: Date;
}

const REMINDER_OFFSETS_MS: Record<ReminderInterval, number> = {
  '12h': 12 * 60 * 60 * 1000,
  '3h': 3 * 60 * 60 * 1000,
  '1h': 60 * 60 * 1000,
  '30m': 30 * 60 * 1000,
  '5m': 5 * 60 * 1000,
};

const REMINDER_ORDER: ReminderInterval[] = ['12h', '3h', '1h', '30m', '5m'];

/**
 * Incomplete Tap Reminders for one user: the fixed 12h/3h/1h/30m/5m-remaining
 * checkpoints before this cycle's cycleEndUTC, for a user who hasn't tapped
 * yet. Returns [] once that user has tapped — the spec is explicit these are
 * sent "only" to a user still outstanding for the cycle.
 *
 * Only checkpoints still ahead of nowUTC are returned, so this is safe to
 * call repeatedly (e.g. on every app resume, or a periodic tick) without
 * re-surfacing a reminder whose moment has already passed — the caller
 * schedules whatever comes back and doesn't need to track "already sent"
 * state itself for checkpoints this function has already dropped.
 */
export function getUpcomingTapReminders(
  cycle: CycleRecord,
  hasTapped: boolean,
  nowUTC: Date
): ScheduledReminder[] {
  if (hasTapped) return [];
  return REMINDER_ORDER.map((interval) => ({
    interval,
    fireAtUTC: new Date(cycle.cycleEndUTC.getTime() - REMINDER_OFFSETS_MS[interval]),
  })).filter(
    (reminder) =>
      reminder.fireAtUTC.getTime() > nowUTC.getTime() &&
      reminder.fireAtUTC.getTime() >= cycle.cycleStartUTC.getTime()
  );
}

/** Cycle Reset Notification: fires once, at this cycle's own end boundary. */
export function getCycleResetFireTime(cycle: CycleRecord): Date {
  return cycle.cycleEndUTC;
}
