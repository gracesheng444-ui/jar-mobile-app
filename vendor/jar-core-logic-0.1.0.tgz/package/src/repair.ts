import { CycleRecord, Jar } from './types';

/** Which of the two users still owe a tap for this cycle. */
export function getMissingUserIds(cycle: CycleRecord, jar: Jar): string[] {
  const missing: string[] = [];
  if (!cycle.userATapped) missing.push(jar.userAId);
  if (!cycle.userBTapped) missing.push(jar.userBId);
  return missing;
}

/**
 * Either user in the jar can spend a repair pass during the 24h grace window
 * to revive the link — regardless of which of them (one or both) actually
 * missed the tap. A single repair fully resolves the cycle; there's no
 * per-missing-user requirement, since a full miss (both forgot) is common
 * and shouldn't need two independent actions to undo.
 */
export function applyRepair(
  cycle: CycleRecord,
  jar: Jar,
  userId: string,
  nowUTC: Date
): CycleRecord {
  if (cycle.status !== 'incomplete_grace') {
    throw new Error(`Cannot repair a cycle with status "${cycle.status}"`);
  }
  if (!cycle.graceExpiresAtUTC || nowUTC > cycle.graceExpiresAtUTC) {
    throw new Error('Grace period has expired');
  }
  if (userId !== jar.userAId && userId !== jar.userBId) {
    throw new Error('User is not a member of this jar');
  }

  return {
    ...cycle,
    repairedBy: [userId],
    status: 'repaired',
  };
}
