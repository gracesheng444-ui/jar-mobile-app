import { CycleRecord, Jar } from './types';

/** Which of the two users still owe a tap for this cycle. */
export function getMissingUserIds(cycle: CycleRecord, jar: Jar): string[] {
  const missing: string[] = [];
  if (!cycle.userATapped) missing.push(jar.userAId);
  if (!cycle.userBTapped) missing.push(jar.userBId);
  return missing;
}

/**
 * A missing user manually spends a repair pass during the 24h grace window.
 * Only the user(s) who actually missed need to act — a partial miss (one
 * user tapped, one didn't) resolves with a single repair from the user who
 * missed. A full miss needs both users to repair independently before the
 * cycle is considered resolved.
 */
export function applyRepair(
  cycle: CycleRecord,
  jar: Jar,
  userId: string,
  nowUTC: Date
): CycleRecord {
  if (cycle.status !== 'incomplete_grace') {
    throw new Error(`Cannot repair a cycle with status "${cycle.status}"`);
  }
  if (!cycle.graceExpiresAtUTC || nowUTC > cycle.graceExpiresAtUTC) {
    throw new Error('Grace period has expired');
  }

  const missing = getMissingUserIds(cycle, jar);
  if (!missing.includes(userId)) {
    throw new Error('This user already completed their tap for this cycle');
  }
  if (cycle.repairedBy.includes(userId)) {
    throw new Error('This user has already spent a repair on this cycle');
  }

  const repairedBy = [...cycle.repairedBy, userId];
  const stillMissing = missing.filter((id) => !repairedBy.includes(id));

  return {
    ...cycle,
    repairedBy,
    status: stillMissing.length === 0 ? 'repaired' : 'incomplete_grace',
  };
}
