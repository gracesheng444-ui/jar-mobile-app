import { UserProfile } from './types';

export const MONTHLY_REPAIR_ALLOWANCE = 3;

/** "YYYY-MM" for the given instant, evaluated in the given IANA timezone. */
export function getLocalYearMonth(atUTC: Date, ianaTimeZone: string): string {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: ianaTimeZone,
    year: 'numeric',
    month: '2-digit',
  });
  const parts = formatter.formatToParts(atUTC);
  const year = parts.find((p) => p.type === 'year')!.value;
  const month = parts.find((p) => p.type === 'month')!.value;
  return `${year}-${month}`;
}

/**
 * Refills the user's quota if their current local month differs from the
 * last month they were refilled in. Idempotent by design (latched on the
 * YYYY-MM string) so it's safe to call this on every read, not just once at
 * app launch — necessary because a user's synced timezone can go stale
 * between launches, and a repair-spend attempt needs the up-to-date balance
 * regardless of whether the app happens to be open.
 */
export function refillIfDue(user: UserProfile, nowUTC: Date): UserProfile {
  const currentYearMonth = getLocalYearMonth(nowUTC, user.currentIANATimezone);
  if (user.lastRefilledYYYYMM === currentYearMonth) {
    return user;
  }
  return {
    ...user,
    repairBalance: MONTHLY_REPAIR_ALLOWANCE,
    lastRefilledYYYYMM: currentYearMonth,
  };
}

/** Lazily refills (if due) before spending, so callers never need to call refillIfDue separately. */
export function spendRepair(user: UserProfile, nowUTC: Date): UserProfile {
  const refreshed = refillIfDue(user, nowUTC);
  if (refreshed.repairBalance <= 0) {
    throw new Error('No repair passes remaining this month');
  }
  return { ...refreshed, repairBalance: refreshed.repairBalance - 1, lastRepairUsedAtUTC: nowUTC };
}
