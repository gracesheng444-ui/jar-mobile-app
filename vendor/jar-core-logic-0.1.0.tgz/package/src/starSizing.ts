export const DEFAULT_VISUAL_CAPACITY = 60;
export const SHRINK_THRESHOLD_FRACTION = 2 / 3;

export interface SizingConfig {
  baseSize: number;
  minSize: number;
  /** Steepness of the post-threshold decay. 1 = linear-in-inverse (default). */
  decayExponent?: number;
}

/** Mode A (countdown): capacity is fixed once, at creation. Never recalculated. */
export function computeCountdownCapacity(remainingDaysAtCreation: number): number {
  if (remainingDaysAtCreation <= 0) {
    throw new Error('remainingDaysAtCreation must be positive');
  }
  return 2 * remainingDaysAtCreation;
}

/**
 * Mode B (count-up): visual capacity used purely as a soft fill-ratio
 * denominator, not a hard slot count — so nothing breaks if actual star
 * count later exceeds it. Uses 2x the creator's optional day estimate,
 * matching the Mode A formula, or a flat default if no estimate was given.
 */
export function computeVisualCapacity(estimatedDaysApart?: number): number {
  return estimatedDaysApart && estimatedDaysApart > 0
    ? 2 * estimatedDaysApart
    : DEFAULT_VISUAL_CAPACITY;
}

/**
 * Star size for count-up mode. Flat at baseSize until 2/3 of visual
 * capacity, then decays asymptotically toward minSize — continuous at the
 * threshold, never fully collapsing regardless of how far past the
 * estimate the count grows.
 */
export function computeStarSize(
  currentCount: number,
  visualCapacity: number,
  config: SizingConfig
): number {
  const { baseSize, minSize, decayExponent = 1 } = config;
  const threshold = SHRINK_THRESHOLD_FRACTION * visualCapacity;
  if (currentCount <= threshold || threshold <= 0) {
    return baseSize;
  }
  const ratio = Math.pow(threshold / currentCount, decayExponent);
  return minSize + (baseSize - minSize) * ratio;
}

/**
 * One-time count-up -> countdown conversion. Recomputes capacity from the
 * remaining days at the moment of conversion; from here on the jar behaves
 * exactly like a native Mode A jar (fixed capacity and size, no more
 * shrinking).
 */
export function convertCountupToCountdown(
  remainingDaysAtConversion: number,
  fixedSize: number
): { capacity: number; fixedSize: number } {
  return {
    capacity: computeCountdownCapacity(remainingDaysAtConversion),
    fixedSize,
  };
}
