import { CycleRecord, StreakState } from './types';

/** Applied the instant a cycle closes — resets are immediate, never silent. */
export function updateStreakOnCycleClose(streak: StreakState, cycle: CycleRecord): StreakState {
  if (cycle.status === 'complete') {
    const currentStreak = streak.currentStreak + 1;
    return {
      ...streak,
      currentStreak,
      longestStreak: Math.max(streak.longestStreak, currentStreak),
      lastUpdatedCycleIndex: cycle.cycleIndex,
    };
  }
  if (cycle.status === 'incomplete_grace' || cycle.status === 'incomplete_expired') {
    return {
      ...streak,
      currentStreak: 0,
      lastUpdatedCycleIndex: cycle.cycleIndex,
    };
  }
  throw new Error(
    `updateStreakOnCycleClose called on an unresolved cycle (status "${cycle.status}")`
  );
}

/**
 * Freeze model: a successful repair restores the streak to whatever it was
 * immediately before the cycle broke it. It does NOT increment — nobody
 * actually completed a mutual tap that day, so no day is credited. The
 * repair's only job is to stop the miss from being held against the pair.
 */
export function restoreStreakAfterRepair(streak: StreakState, cycle: CycleRecord): StreakState {
  if (cycle.status !== 'repaired') {
    throw new Error('Cycle must be marked "repaired" before the streak can be restored');
  }
  const restored = Math.max(streak.currentStreak, cycle.streakBeforeCycle);
  return {
    ...streak,
    currentStreak: restored,
    longestStreak: Math.max(streak.longestStreak, restored),
    lastUpdatedCycleIndex: cycle.cycleIndex,
  };
}
