import { CycleRecord, StreakState } from './types';

/**
 * Derives the authoritative streak by folding cycles in strict cycleIndex
 * order, starting just after the last cycle already folded in. This makes
 * the result independent of the real-world order in which cycle closures,
 * repairs, and expiries actually happen: a later cycle's completion is
 * never counted (or discarded) by an earlier cycle's repair that resolves
 * out of order — folding simply halts at the first unresolved cycle and
 * picks back up from there once it's resolved.
 *
 * An unresolved break (incomplete_grace) still zeroes the visible streak
 * immediately — that part is never silent — but lastUpdatedCycleIndex is
 * NOT advanced past it, so the next call re-examines that same cycle once
 * it's repaired or its grace period expires, and only then continues
 * folding into whatever comes after it.
 */
export function recomputeStreak(streak: StreakState, cycles: CycleRecord[]): StreakState {
  const sorted = [...cycles].sort((a, b) => a.cycleIndex - b.cycleIndex);
  let currentStreak = streak.currentStreak;
  let longestStreak = streak.longestStreak;
  let lastResolvedIndex = streak.lastUpdatedCycleIndex;

  for (const cycle of sorted) {
    if (cycle.cycleIndex <= lastResolvedIndex) continue;
    if (cycle.cycleIndex !== lastResolvedIndex + 1) break;

    if (cycle.status === 'complete') {
      currentStreak += 1;
      longestStreak = Math.max(longestStreak, currentStreak);
      lastResolvedIndex = cycle.cycleIndex;
    } else if (cycle.status === 'repaired') {
      currentStreak = Math.max(currentStreak, cycle.streakBeforeCycle);
      longestStreak = Math.max(longestStreak, currentStreak);
      lastResolvedIndex = cycle.cycleIndex;
    } else if (cycle.status === 'incomplete_expired') {
      currentStreak = 0;
      lastResolvedIndex = cycle.cycleIndex;
    } else if (cycle.status === 'incomplete_grace') {
      currentStreak = 0;
      break;
    } else {
      break; // 'open' — still in progress, nothing to fold yet.
    }
  }

  return { ...streak, currentStreak, longestStreak, lastUpdatedCycleIndex: lastResolvedIndex };
}
