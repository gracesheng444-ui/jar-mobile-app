export type JarMode = 'countdown' | 'countup';

export interface Jar {
  id: string;
  userAId: string;
  userBId: string;
  createdAtUTC: Date;
  mode: JarMode;
  targetDateUTC?: Date;
  // Fixed once at creation (countdown) or at count-up -> countdown conversion.
  starCapacityN?: number;
  starSizeFixed?: number;
  // Count-up mode only. Optional rough estimate the creator can supply, and
  // either partner can edit later in settings (single shared value, last
  // write wins). Feeds visualCapacityConstant below.
  estimatedDaysApart?: number;
  visualCapacityConstant?: number;
}

export type CycleStatus =
  | 'open'
  | 'complete'
  | 'incomplete_grace'
  | 'incomplete_expired'
  | 'repaired';

export interface CycleRecord {
  jarId: string;
  cycleIndex: number;
  cycleStartUTC: Date;
  cycleEndUTC: Date;
  userATapped: boolean;
  userBTapped: boolean;
  status: CycleStatus;
  graceExpiresAtUTC?: Date;
  repairedBy: string[];
  // Snapshot of the streak value at the moment this cycle opened, so a later
  // repair can restore (freeze) rather than needing external history lookups.
  streakBeforeCycle: number;
}

export interface StreakState {
  jarId: string;
  currentStreak: number;
  longestStreak: number;
  lastUpdatedCycleIndex: number;
}

export interface UserProfile {
  id: string;
  currentIANATimezone: string;
  repairBalance: number;
  // e.g. "2026-08" — the last local year-month this user's quota was
  // refilled in. Used as an idempotency guard against double refills.
  lastRefilledYYYYMM: string | null;
}
