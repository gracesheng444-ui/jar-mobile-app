import {
  AVATAR_OPTIONS,
  DEFAULT_AVATAR_CONFIG,
  buildAvatarFromSelections,
  setAvatarTrait,
  cycleAvatarTrait,
  randomizeAvatar,
  validateAvatarConfig,
  createAvatarRecord,
} from '../src/avatar';

describe('manual construction', () => {
  test('buildAvatarFromSelections fills unset traits from defaults', () => {
    const config = buildAvatarFromSelections({ hairColor: 'blue' });
    expect(config.hairColor).toBe('blue');
    expect(config.faceShape).toBe(DEFAULT_AVATAR_CONFIG.faceShape);
  });

  test('buildAvatarFromSelections rejects a value outside the catalog', () => {
    expect(() => buildAvatarFromSelections({ hairColor: 'invisible' as any })).toThrow();
  });

  test('setAvatarTrait updates one trait and leaves the rest untouched', () => {
    const updated = setAvatarTrait(DEFAULT_AVATAR_CONFIG, 'accessory', 'hat');
    expect(updated.accessory).toBe('hat');
    expect(updated.skinTone).toBe(DEFAULT_AVATAR_CONFIG.skinTone);
  });

  test('setAvatarTrait supports eyeColor and clothing', () => {
    const withEyeColor = setAvatarTrait(DEFAULT_AVATAR_CONFIG, 'eyeColor', 'green');
    expect(withEyeColor.eyeColor).toBe('green');

    const withClothing = setAvatarTrait(DEFAULT_AVATAR_CONFIG, 'clothing', 'purple');
    expect(withClothing.clothing).toBe('purple');
  });

  test('setAvatarTrait rejects invalid eyeColor and clothing values', () => {
    expect(() => setAvatarTrait(DEFAULT_AVATAR_CONFIG, 'eyeColor', 'rainbow' as any)).toThrow();
    expect(() => setAvatarTrait(DEFAULT_AVATAR_CONFIG, 'clothing', 'toga' as any)).toThrow();
  });

  test('setAvatarTrait rejects an invalid value', () => {
    expect(() => setAvatarTrait(DEFAULT_AVATAR_CONFIG, 'accessory', 'monocle' as any)).toThrow();
  });

  test('cycleAvatarTrait steps forward and wraps around', () => {
    const options = AVATAR_OPTIONS.eyeStyle;
    const last = setAvatarTrait(DEFAULT_AVATAR_CONFIG, 'eyeStyle', options[options.length - 1]);
    const wrapped = cycleAvatarTrait(last, 'eyeStyle', 1);
    expect(wrapped.eyeStyle).toBe(options[0]);
  });

  test('cycleAvatarTrait steps backward and wraps around', () => {
    const first = setAvatarTrait(DEFAULT_AVATAR_CONFIG, 'mouthStyle', AVATAR_OPTIONS.mouthStyle[0]);
    const wrapped = cycleAvatarTrait(first, 'mouthStyle', -1);
    expect(wrapped.mouthStyle).toBe(AVATAR_OPTIONS.mouthStyle[AVATAR_OPTIONS.mouthStyle.length - 1]);
  });

  test('randomizeAvatar is deterministic given a fixed random source', () => {
    const constant = () => 0;
    const a = randomizeAvatar(constant);
    const b = randomizeAvatar(constant);
    expect(a).toEqual(b);
    expect(a.skinTone).toBe(AVATAR_OPTIONS.skinTone[0]);
  });
});

describe('photo-to-AI pipeline contract', () => {
  test('validateAvatarConfig accepts a fully-populated candidate', () => {
    const candidate = { ...DEFAULT_AVATAR_CONFIG, hairStyle: 'curly' };
    expect(validateAvatarConfig(candidate)).toEqual({ ...DEFAULT_AVATAR_CONFIG, hairStyle: 'curly' });
  });

  test('validateAvatarConfig rejects a missing trait', () => {
    const { hairStyle, ...incomplete } = DEFAULT_AVATAR_CONFIG;
    expect(() => validateAvatarConfig(incomplete)).toThrow();
  });

  test('validateAvatarConfig rejects an out-of-catalog value', () => {
    const candidate = { ...DEFAULT_AVATAR_CONFIG, background: 'plaid' };
    expect(() => validateAvatarConfig(candidate)).toThrow();
  });

  test('createAvatarRecord requires a sourcePhotoId for photo_ai avatars', () => {
    const now = new Date('2026-01-01T00:00:00Z');
    expect(() => createAvatarRecord('alice', DEFAULT_AVATAR_CONFIG, 'photo_ai', now)).toThrow();
    const record = createAvatarRecord('alice', DEFAULT_AVATAR_CONFIG, 'photo_ai', now, 'photo-123');
    expect(record.sourcePhotoId).toBe('photo-123');
  });

  test('createAvatarRecord allows manual avatars without a sourcePhotoId', () => {
    const now = new Date('2026-01-01T00:00:00Z');
    const record = createAvatarRecord('alice', DEFAULT_AVATAR_CONFIG, 'manual', now);
    expect(record.sourcePhotoId).toBeUndefined();
  });
});
