import {
  getCycleIndexForTimestamp,
  getCycleWindow,
  openCycle,
  closeCycle,
  expireGraceIfNeeded,
  CYCLE_LENGTH_MS,
  GRACE_PERIOD_MS,
} from '../src/cycle';

describe('cycle boundary math', () => {
  const created = new Date('2026-01-01T14:15:00Z');

  test('index 0 for a timestamp right at creation', () => {
    expect(getCycleIndexForTimestamp(created, created)).toBe(0);
  });

  test('index increments exactly at each 24h boundary', () => {
    const oneCycleLater = new Date(created.getTime() + CYCLE_LENGTH_MS);
    expect(getCycleIndexForTimestamp(created, oneCycleLater)).toBe(1);
    const justBefore = new Date(oneCycleLater.getTime() - 1);
    expect(getCycleIndexForTimestamp(created, justBefore)).toBe(0);
  });

  test('throws for a timestamp before creation', () => {
    const before = new Date(created.getTime() - 1);
    expect(() => getCycleIndexForTimestamp(created, before)).toThrow();
  });

  test('getCycleWindow round-trips with getCycleIndexForTimestamp', () => {
    const { start, end } = getCycleWindow(created, 5);
    expect(getCycleIndexForTimestamp(created, start)).toBe(5);
    expect(end.getTime() - start.getTime()).toBe(CYCLE_LENGTH_MS);
  });
});

describe('closeCycle', () => {
  const created = new Date('2026-01-01T00:00:00Z');

  test('both tapped -> complete', () => {
    let cycle = openCycle('jar1', created, 0, 3);
    cycle = { ...cycle, userATapped: true, userBTapped: true };
    expect(closeCycle(cycle).status).toBe('complete');
  });

  test('one missing -> incomplete_grace with a 24h grace window', () => {
    let cycle = openCycle('jar1', created, 0, 3);
    cycle = { ...cycle, userATapped: true, userBTapped: false };
    const closed = closeCycle(cycle);
    expect(closed.status).toBe('incomplete_grace');
    expect(closed.graceExpiresAtUTC!.getTime() - closed.cycleEndUTC.getTime()).toBe(
      GRACE_PERIOD_MS
    );
  });

  test('cannot close a cycle twice', () => {
    let cycle = openCycle('jar1', created, 0, 0);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: true });
    expect(() => closeCycle(cycle)).toThrow();
  });
});

describe('expireGraceIfNeeded', () => {
  const created = new Date('2026-01-01T00:00:00Z');

  test('flips to incomplete_expired once grace passes', () => {
    let cycle = openCycle('jar1', created, 0, 0);
    cycle = closeCycle({ ...cycle, userATapped: false, userBTapped: false });
    const afterGrace = new Date(cycle.graceExpiresAtUTC!.getTime() + 1);
    expect(expireGraceIfNeeded(cycle, afterGrace).status).toBe('incomplete_expired');
  });

  test('leaves an in-progress grace period untouched', () => {
    let cycle = openCycle('jar1', created, 0, 0);
    cycle = closeCycle({ ...cycle, userATapped: false, userBTapped: false });
    const duringGrace = new Date(cycle.cycleEndUTC.getTime() + 1000);
    expect(expireGraceIfNeeded(cycle, duringGrace).status).toBe('incomplete_grace');
  });
});
