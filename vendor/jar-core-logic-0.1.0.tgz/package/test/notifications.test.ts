import { openCycle } from '../src/cycle';
import { getUpcomingTapReminders, getCycleResetFireTime } from '../src/notifications';

describe('incomplete tap reminders', () => {
  const jarCreated = new Date('2026-01-01T00:00:00Z');
  const cycle = openCycle('jar-1', jarCreated, 0, 0); // 24h cycle: 2026-01-01T00:00Z -> 2026-01-02T00:00Z

  test('returns all five checkpoints, in order, right at cycle start', () => {
    const reminders = getUpcomingTapReminders(cycle, false, jarCreated);
    expect(reminders.map((r) => r.interval)).toEqual(['12h', '3h', '1h', '30m', '5m']);
    expect(reminders[0].fireAtUTC).toEqual(new Date('2026-01-01T12:00:00Z'));
    expect(reminders[4].fireAtUTC).toEqual(new Date('2026-01-01T23:55:00Z'));
  });

  test('returns nothing once this user has tapped', () => {
    expect(getUpcomingTapReminders(cycle, true, jarCreated)).toEqual([]);
  });

  test('drops checkpoints that have already passed relative to now', () => {
    const midway = new Date('2026-01-01T22:00:00Z'); // 2h remaining
    const reminders = getUpcomingTapReminders(cycle, false, midway);
    expect(reminders.map((r) => r.interval)).toEqual(['1h', '30m', '5m']);
  });

  test('returns nothing once the cycle has already fully closed', () => {
    const afterEnd = new Date('2026-01-02T00:00:01Z');
    expect(getUpcomingTapReminders(cycle, false, afterEnd)).toEqual([]);
  });
});

describe('cycle reset notification', () => {
  test('fires at the cycle end boundary', () => {
    const jarCreated = new Date('2026-01-01T00:00:00Z');
    const cycle = openCycle('jar-1', jarCreated, 0, 0);
    expect(getCycleResetFireTime(cycle)).toEqual(cycle.cycleEndUTC);
  });
});
