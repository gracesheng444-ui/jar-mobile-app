import { refillIfDue, spendRepair } from '../src/repairQuota';
import { UserProfile } from '../src/types';

function user(overrides: Partial<UserProfile> = {}): UserProfile {
  return {
    id: 'u1',
    currentIANATimezone: 'Asia/Singapore',
    repairBalance: 0,
    lastRefilledYYYYMM: null,
    ...overrides,
  };
}

describe('monthly refill', () => {
  test('refills on first check', () => {
    const refreshed = refillIfDue(user(), new Date('2026-08-15T00:00:00Z'));
    expect(refreshed.repairBalance).toBe(3);
    expect(refreshed.lastRefilledYYYYMM).toBe('2026-08');
  });

  test('does not refill twice within the same local month (idempotent)', () => {
    let u = refillIfDue(user(), new Date('2026-08-01T00:00:01Z'));
    u = { ...u, repairBalance: 1 }; // simulate 2 already spent
    const stillOne = refillIfDue(u, new Date('2026-08-20T00:00:00Z'));
    expect(stillOne.repairBalance).toBe(1);
  });

  test('refills again once the local month rolls over', () => {
    const augUser = refillIfDue(user(), new Date('2026-08-15T00:00:00Z'));
    const spent = { ...augUser, repairBalance: 0 };
    const sept = refillIfDue(spent, new Date('2026-09-01T00:00:01Z'));
    expect(sept.repairBalance).toBe(3);
    expect(sept.lastRefilledYYYYMM).toBe('2026-09');
  });

  test('respects the user-specific IANA timezone, not UTC', () => {
    // 2026-08-31T17:00:00Z is already 2026-09-01 01:00 in Singapore (UTC+8)
    const nearMonthEnd = new Date('2026-08-31T17:00:00Z');
    const sg = refillIfDue(user({ lastRefilledYYYYMM: '2026-08' }), nearMonthEnd);
    expect(sg.lastRefilledYYYYMM).toBe('2026-09');

    // The same instant is still 2026-08-31 in US Eastern (UTC-4) — no refill yet.
    const et = refillIfDue(
      user({ currentIANATimezone: 'America/New_York', lastRefilledYYYYMM: '2026-08' }),
      nearMonthEnd
    );
    expect(et.lastRefilledYYYYMM).toBe('2026-08');
  });
});

describe('spendRepair', () => {
  test('lazily refills before spending if the month has turned over', () => {
    const stale = user({ repairBalance: 0, lastRefilledYYYYMM: '2026-07' });
    const result = spendRepair(stale, new Date('2026-08-15T00:00:00Z'));
    expect(result.repairBalance).toBe(2); // refilled to 3, then 1 spent
  });

  test('throws when balance is exhausted for the current month', () => {
    const exhausted = user({ repairBalance: 0, lastRefilledYYYYMM: '2026-08' });
    expect(() => spendRepair(exhausted, new Date('2026-08-15T00:00:00Z'))).toThrow();
  });
});
