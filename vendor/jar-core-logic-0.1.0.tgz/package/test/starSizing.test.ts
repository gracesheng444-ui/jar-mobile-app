import {
  computeStarSize,
  computeVisualCapacity,
  computeCountdownCapacity,
  convertCountupToCountdown,
  DEFAULT_VISUAL_CAPACITY,
} from '../src/starSizing';

const config = { baseSize: 24, minSize: 8 };

describe('count-up shrink curve', () => {
  test('stays at base size at and below the 2/3 threshold', () => {
    expect(computeStarSize(30, 60, config)).toBe(24);
    expect(computeStarSize(40, 60, config)).toBe(24); // exactly at threshold
  });

  test('is continuous at the threshold boundary (no visual jump)', () => {
    const atThreshold = computeStarSize(40, 60, config);
    const justPast = computeStarSize(41, 60, config);
    expect(justPast).toBeLessThanOrEqual(atThreshold);
    expect(atThreshold - justPast).toBeLessThan(1);
  });

  test('asymptotically approaches but never reaches minSize', () => {
    const farPast = computeStarSize(6000, 60, config);
    expect(farPast).toBeGreaterThan(config.minSize);
    expect(farPast).toBeLessThan(9);
  });

  test('a steeper decayExponent shrinks faster past the threshold', () => {
    const gentle = computeStarSize(80, 60, { ...config, decayExponent: 1 });
    const steep = computeStarSize(80, 60, { ...config, decayExponent: 2 });
    expect(steep).toBeLessThan(gentle);
  });
});

describe('visual capacity (count-up)', () => {
  test('uses 2x the estimate when the couple provides one', () => {
    expect(computeVisualCapacity(30)).toBe(60);
  });

  test('falls back to the default constant when no estimate is given', () => {
    expect(computeVisualCapacity(undefined)).toBe(DEFAULT_VISUAL_CAPACITY);
  });
});

describe('countdown capacity (Mode A)', () => {
  test('is exactly 2x remaining days', () => {
    expect(computeCountdownCapacity(45)).toBe(90);
  });

  test('rejects non-positive day counts', () => {
    expect(() => computeCountdownCapacity(0)).toThrow();
  });
});

describe('count-up -> countdown conversion', () => {
  test('recomputes capacity from remaining days at conversion time', () => {
    const result = convertCountupToCountdown(10, 24);
    expect(result.capacity).toBe(20);
    expect(result.fixedSize).toBe(24);
  });
});
