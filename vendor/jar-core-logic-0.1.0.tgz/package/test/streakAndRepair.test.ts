import { openCycle, closeCycle } from '../src/cycle';
import { applyRepair, getMissingUserIds } from '../src/repair';
import { updateStreakOnCycleClose, restoreStreakAfterRepair } from '../src/streak';
import { Jar, StreakState } from '../src/types';

const jar: Jar = {
  id: 'jar1',
  userAId: 'alice',
  userBId: 'bob',
  createdAtUTC: new Date('2026-01-01T00:00:00Z'),
  mode: 'countup',
};

function freshStreak(current = 5): StreakState {
  return { jarId: jar.id, currentStreak: current, longestStreak: current, lastUpdatedCycleIndex: -1 };
}

describe('streak progression', () => {
  test('a complete cycle increments the streak', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: true });
    const streak = updateStreakOnCycleClose(freshStreak(5), cycle);
    expect(streak.currentStreak).toBe(6);
    expect(streak.longestStreak).toBe(6);
  });

  test('an incomplete cycle resets the streak to 0 immediately, not silently', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: false });
    const streak = updateStreakOnCycleClose(freshStreak(5), cycle);
    expect(streak.currentStreak).toBe(0);
  });
});

describe('repair — partial miss (one user)', () => {
  test('only the missing user can repair, and it alone resolves the cycle', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: false });
    expect(getMissingUserIds(cycle, jar)).toEqual(['bob']);

    // Alice already tapped — she has nothing to repair.
    expect(() => applyRepair(cycle, jar, 'alice', cycle.cycleEndUTC)).toThrow();

    const repaired = applyRepair(cycle, jar, 'bob', cycle.cycleEndUTC);
    expect(repaired.status).toBe('repaired');
  });

  test('repair freezes the streak — restores prior value, no +1 credit', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: false });
    cycle = applyRepair(cycle, jar, 'bob', cycle.cycleEndUTC);

    const brokenStreak = updateStreakOnCycleClose(freshStreak(5), {
      ...cycle,
      status: 'incomplete_grace',
    });
    expect(brokenStreak.currentStreak).toBe(0);

    const restored = restoreStreakAfterRepair(brokenStreak, cycle);
    expect(restored.currentStreak).toBe(5); // back to pre-cycle value, not 6
  });
});

describe('repair — full miss (both users)', () => {
  test('cycle stays incomplete until both users repair independently', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: false, userBTapped: false });

    const afterOne = applyRepair(cycle, jar, 'alice', cycle.cycleEndUTC);
    expect(afterOne.status).toBe('incomplete_grace');

    const afterBoth = applyRepair(afterOne, jar, 'bob', cycle.cycleEndUTC);
    expect(afterBoth.status).toBe('repaired');
  });

  test('a user cannot spend a repair on the same cycle twice', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: false, userBTapped: false });
    const once = applyRepair(cycle, jar, 'alice', cycle.cycleEndUTC);
    expect(() => applyRepair(once, jar, 'alice', cycle.cycleEndUTC)).toThrow();
  });
});

describe('repair — grace period expiry', () => {
  test('repair fails once the 24h window has passed', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: false });
    const tooLate = new Date(cycle.graceExpiresAtUTC!.getTime() + 1);
    expect(() => applyRepair(cycle, jar, 'bob', tooLate)).toThrow();
  });
});
