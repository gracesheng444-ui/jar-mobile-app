import { openCycle, closeCycle } from '../src/cycle';
import { applyRepair, getMissingUserIds } from '../src/repair';
import { recomputeStreak } from '../src/streak';
import { CycleRecord, Jar, StreakState } from '../src/types';

const jar: Jar = {
  id: 'jar1',
  userAId: 'alice',
  userBId: 'bob',
  createdAtUTC: new Date('2026-01-01T00:00:00Z'),
  mode: 'countup',
};

function freshStreak(current = 5): StreakState {
  return { jarId: jar.id, currentStreak: current, longestStreak: current, lastUpdatedCycleIndex: -1 };
}

describe('streak progression', () => {
  test('a complete cycle increments the streak', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: true });
    const streak = recomputeStreak(freshStreak(5), [cycle]);
    expect(streak.currentStreak).toBe(6);
    expect(streak.longestStreak).toBe(6);
  });

  test('an incomplete cycle resets the streak to 0 immediately, not silently', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: false });
    const streak = recomputeStreak(freshStreak(5), [cycle]);
    expect(streak.currentStreak).toBe(0);
    // Still pending repair — not folded in as resolved yet.
    expect(streak.lastUpdatedCycleIndex).toBe(-1);
  });
});

describe('repair — partial miss (one user)', () => {
  test('either user can repair, and a single repair resolves the cycle', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: false });
    expect(getMissingUserIds(cycle, jar)).toEqual(['bob']);

    // Alice already tapped, but she can still spend the repair on Bob's behalf.
    const repaired = applyRepair(cycle, jar, 'alice', cycle.cycleEndUTC);
    expect(repaired.status).toBe('repaired');
  });

  test('repair freezes the streak — restores prior value, no +1 credit', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: false });

    // Visible immediately, before anyone has repaired.
    const brokenStreak = recomputeStreak(freshStreak(5), [cycle]);
    expect(brokenStreak.currentStreak).toBe(0);

    cycle = applyRepair(cycle, jar, 'bob', cycle.cycleEndUTC);
    const restored = recomputeStreak(brokenStreak, [cycle]);
    expect(restored.currentStreak).toBe(5); // back to pre-cycle value, not 6
    expect(restored.lastUpdatedCycleIndex).toBe(0);
  });
});

describe('repair — full miss (both users)', () => {
  test('a single repair from either user resolves the cycle, even if both forgot', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: false, userBTapped: false });

    const repaired = applyRepair(cycle, jar, 'alice', cycle.cycleEndUTC);
    expect(repaired.status).toBe('repaired');
  });

  test('a cycle cannot be repaired twice', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: false, userBTapped: false });
    const once = applyRepair(cycle, jar, 'alice', cycle.cycleEndUTC);
    expect(() => applyRepair(once, jar, 'bob', cycle.cycleEndUTC)).toThrow();
  });

  test('rejects a repair attempt from someone outside the jar', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: false, userBTapped: false });
    expect(() => applyRepair(cycle, jar, 'stranger', cycle.cycleEndUTC)).toThrow();
  });
});

describe('repair — grace period expiry', () => {
  test('repair fails once the 24h window has passed', () => {
    let cycle = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    cycle = closeCycle({ ...cycle, userATapped: true, userBTapped: false });
    const tooLate = new Date(cycle.graceExpiresAtUTC!.getTime() + 1);
    expect(() => applyRepair(cycle, jar, 'bob', tooLate)).toThrow();
  });
});

describe('streak folding is order-independent across cycles', () => {
  // Streak was 5. Cycle 0 breaks. Cycle 1 (the next day) gets mutual-tapped
  // to completion while cycle 0 is still unrepaired. The final streak must
  // land on 6 (5 restored + 1 for day 1) no matter whether cycle 0's repair
  // or cycle 1's completion is folded in "first" — the fold always resolves
  // by cycleIndex, not by arrival order.
  function brokenThenCompletedCycles(): { broken: CycleRecord; next: CycleRecord } {
    let broken = openCycle(jar.id, jar.createdAtUTC, 0, 5);
    broken = closeCycle({ ...broken, userATapped: true, userBTapped: false });

    let next = openCycle(jar.id, jar.createdAtUTC, 1, 0); // 0 is a placeholder; recompute ignores it
    next = closeCycle({ ...next, userATapped: true, userBTapped: true });

    return { broken, next };
  }

  test('repair resolves before the next cycle is folded in', () => {
    const { broken, next } = brokenThenCompletedCycles();
    const repaired = applyRepair(broken, jar, 'bob', broken.cycleEndUTC);

    let streak = freshStreak(5);
    streak = recomputeStreak(streak, [repaired]); // repair folded first
    streak = recomputeStreak(streak, [next]); // then the completed next cycle

    expect(streak.currentStreak).toBe(6);
  });

  test('the next cycle completes before the repair lands, but the fold still gets it right', () => {
    const { broken, next } = brokenThenCompletedCycles();
    const repaired = applyRepair(broken, jar, 'bob', broken.cycleEndUTC);

    let streak = freshStreak(5);
    // Both cycle records are already final by the time we recompute, but
    // cycle 0 was NOT folded in yet (lastUpdatedCycleIndex is still -1) —
    // this is the "next cycle finished first in real time" scenario.
    streak = recomputeStreak(streak, [next, repaired]);

    expect(streak.currentStreak).toBe(6);
  });

  test('the next cycle cannot be credited while cycle 0 is still unrepaired', () => {
    const { broken, next } = brokenThenCompletedCycles();

    let streak = freshStreak(5);
    streak = recomputeStreak(streak, [broken, next]);

    // Folding halts at cycle 0 — its completion can't be trusted yet, so
    // cycle 1's completion isn't counted either, even though it's already
    // "complete" in the data.
    expect(streak.currentStreak).toBe(0);
    expect(streak.lastUpdatedCycleIndex).toBe(-1);
  });
});
